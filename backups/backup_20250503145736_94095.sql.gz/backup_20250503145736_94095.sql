-- DUTSCA Database Backup
-- Created: 2025-05-03 14:57:36


-- Table structure for activity_logs
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for backups
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_type` enum('database','files') NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `size` bigint(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `backups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for blocked_ips
DROP TABLE IF EXISTS `blocked_ips`;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` text DEFAULT NULL,
  `blocked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `blocked_by` (`blocked_by`),
  CONSTRAINT `blocked_ips_ibfk_1` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for blocked_ips
INSERT INTO `blocked_ips` VALUES (2,'192.168.1.2','this ip from hackers',6,'2025-05-02 23:56:57');

-- Table structure for departments
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `head_user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `head_user_id` (`head_user_id`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`head_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for iqub_groups
DROP TABLE IF EXISTS `iqub_groups`;
CREATE TABLE `iqub_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `contribution_amount` decimal(10,2) NOT NULL,
  `total_members` int(11) NOT NULL,
  `current_members` int(11) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cycle_period` enum('weekly','monthly') DEFAULT 'monthly',
  `status` enum('forming','active','completed','cancelled') DEFAULT 'forming',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `iqub_groups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for iqub_members
DROP TABLE IF EXISTS `iqub_members`;
CREATE TABLE `iqub_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `join_date` date NOT NULL,
  `position_number` int(11) DEFAULT NULL,
  `total_contribution` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','won','completed','defaulted') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_member_group` (`group_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `iqub_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `iqub_groups` (`id`),
  CONSTRAINT `iqub_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for iqub_payments
DROP TABLE IF EXISTS `iqub_payments`;
CREATE TABLE `iqub_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `round_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','deduction') NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `round_id` (`round_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `iqub_payments_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `iqub_members` (`id`),
  CONSTRAINT `iqub_payments_ibfk_2` FOREIGN KEY (`round_id`) REFERENCES `iqub_rounds` (`id`),
  CONSTRAINT `iqub_payments_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for iqub_rounds
DROP TABLE IF EXISTS `iqub_rounds`;
CREATE TABLE `iqub_rounds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `round_number` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `winner_id` int(11) DEFAULT NULL,
  `pot_amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','active','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_round` (`group_id`,`round_number`),
  KEY `winner_id` (`winner_id`),
  CONSTRAINT `iqub_rounds_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `iqub_groups` (`id`),
  CONSTRAINT `iqub_rounds_ibfk_2` FOREIGN KEY (`winner_id`) REFERENCES `iqub_members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for login_attempts
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) DEFAULT 0,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `login_attempts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for performance_monitoring
DROP TABLE IF EXISTS `performance_monitoring`;
CREATE TABLE `performance_monitoring` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metric` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `recorded_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recorded_by` (`recorded_by`),
  CONSTRAINT `performance_monitoring_ibfk_1` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for permission_categories
DROP TABLE IF EXISTS `permission_categories`;
CREATE TABLE `permission_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for permission_categories
INSERT INTO `permission_categories` VALUES (1,'User Management','Manage system users and their permissions','fa-users',1,'2025-05-02 23:31:40','2025-05-02 23:31:40');
INSERT INTO `permission_categories` VALUES (2,'Content Management','Manage website content and pages','fa-file-alt',2,'2025-05-02 23:31:40','2025-05-02 23:31:40');
INSERT INTO `permission_categories` VALUES (3,'System Settings','Configure system settings and preferences','fa-cogs',3,'2025-05-02 23:31:40','2025-05-02 23:31:40');
INSERT INTO `permission_categories` VALUES (4,'Reports','Access and generate system reports','fa-chart-bar',4,'2025-05-02 23:31:40','2025-05-02 23:31:40');
INSERT INTO `permission_categories` VALUES (5,'Security','Manage security settings and logs','fa-shield-alt',5,'2025-05-02 23:31:40','2025-05-02 23:31:40');

-- Table structure for permissions
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `requires_approval` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `permission_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for savings
DROP TABLE IF EXISTS `savings`;
CREATE TABLE `savings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('deposit','withdrawal') NOT NULL,
  `description` text DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_number` (`reference_number`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `savings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `savings_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for savings_goals
DROP TABLE IF EXISTS `savings_goals`;
CREATE TABLE `savings_goals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `target_amount` decimal(10,2) NOT NULL,
  `current_amount` decimal(10,2) DEFAULT 0.00,
  `deadline` date DEFAULT NULL,
  `status` enum('active','completed','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `savings_goals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for security_logs
DROP TABLE IF EXISTS `security_logs`;
CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `security_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for security_logs
INSERT INTO `security_logs` VALUES (1,6,'vpn_blocking_update','VPN blocking disabled','::1','2025-05-02 23:04:05');
INSERT INTO `security_logs` VALUES (2,6,'ethiopia_only_update','Ethiopian IP restriction enabled','::1','2025-05-02 23:04:18');
INSERT INTO `security_logs` VALUES (3,6,'vpn_blocking_update','VPN blocking disabled','::1','2025-05-02 23:04:41');
INSERT INTO `security_logs` VALUES (4,6,'vpn_blocking_update','VPN blocking disabled','::1','2025-05-02 23:06:06');
INSERT INTO `security_logs` VALUES (5,6,'security_settings_update','Security settings updated','::1','2025-05-02 23:06:59');
INSERT INTO `security_logs` VALUES (6,6,'ethiopia_only_update','Ethiopian IP restriction enabled','::1','2025-05-02 23:57:15');

-- Table structure for security_settings
DROP TABLE IF EXISTS `security_settings`;
CREATE TABLE `security_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `security_settings_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for security_settings
INSERT INTO `security_settings` VALUES (1,'password_min_length',8,'Minimum password length','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (2,'password_require_special','true','Require special characters in password','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (3,'password_require_uppercase','true','Require uppercase letters in password','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (4,'password_require_number','true','Require numbers in password','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (5,'session_timeout_minutes',30,'Session timeout in minutes','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (6,'require_2fa','false','Require two-factor authentication for all users','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (7,'max_login_attempts',5,'Maximum allowed failed login attempts before lockout','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (8,'account_lockout_duration_minutes',15,'Duration (in minutes) for which account is locked after max failed attempts','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (9,'password_expiry_days',90,'Number of days before password must be changed','2025-05-02 13:59:48',NULL);
INSERT INTO `security_settings` VALUES (10,'allow_password_reuse','false','Allow users to reuse previous passwords','2025-05-02 13:59:48',NULL);

-- Table structure for sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `last_activity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for settings
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for settings
INSERT INTO `settings` VALUES (1,'backup_config','{\"frequency\":\"daily\",\"retention\":30,\"compression\":\"gzip\",\"encryption\":false}','Backup system configuration','2025-05-02 15:12:51','2025-05-02 15:32:00');
INSERT INTO `settings` VALUES (103,'block_vpn',0,'Block VPN/Proxy connections','2025-05-02 22:58:50','2025-05-02 23:02:44');
INSERT INTO `settings` VALUES (114,'ethiopia_only_access',1,'Allow only Ethiopian IP addresses','2025-05-02 23:02:07','2025-05-02 23:02:22');
INSERT INTO `settings` VALUES (115,'min_password_length',8,'Minimum password length','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (116,'require_special_chars',1,'Require special characters in password','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (117,'require_numbers',1,'Require numbers in password','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (118,'require_uppercase',1,'Require uppercase letters in password','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (119,'password_expiry_days',90,'Password expiry in days','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (120,'max_login_attempts',5,'Maximum login attempts before lockout','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (121,'lockout_duration_minutes',30,'Account lockout duration in minutes','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (122,'session_timeout_minutes',30,'Session timeout in minutes','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (123,'require_2fa',0,'Require two-factor authentication','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (124,'ip_whitelist','','Whitelisted IP addresses','2025-05-02 23:06:59','2025-05-02 23:06:59');
INSERT INTO `settings` VALUES (125,'vpn_blocking_enabled',0,'Enable/Disable VPN Blocking','2025-05-02 23:57:15','2025-05-02 23:57:15');

-- Table structure for system_reports
DROP TABLE IF EXISTS `system_reports`;
CREATE TABLE `system_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_type` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `generated_by` int(11) DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','completed','failed') DEFAULT 'completed',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `system_reports_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for system_settings
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text NOT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for system_settings
INSERT INTO `system_settings` VALUES (1,'site_name','DUTSCA','Site Name','2025-05-02 22:57:54');
INSERT INTO `system_settings` VALUES (2,'site_description','DUTSCA Savings and Credit Association','Site Description','2025-05-02 22:57:54');
INSERT INTO `system_settings` VALUES (3,'maintenance_mode','false','Maintenance Mode Status','2025-05-02 22:57:54');
INSERT INTO `system_settings` VALUES (4,'min_savings_amount',100,'Minimum Savings Amount','2025-05-02 22:57:54');
INSERT INTO `system_settings` VALUES (5,'max_withdrawal_amount',10000,'Maximum Withdrawal Amount','2025-05-02 22:57:54');

-- Table structure for system_status
DROP TABLE IF EXISTS `system_status`;
CREATE TABLE `system_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_type` varchar(100) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `checked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `checked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `checked_by` (`checked_by`),
  CONSTRAINT `system_status_ibfk_1` FOREIGN KEY (`checked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for system_updates
DROP TABLE IF EXISTS `system_updates`;
CREATE TABLE `system_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `update_type` enum('security','feature','bugfix','maintenance') NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','applied','failed','rolled_back') NOT NULL DEFAULT 'pending',
  `applied_by` varchar(100) DEFAULT NULL,
  `applied_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for user_activity_logs
DROP TABLE IF EXISTS `user_activity_logs`;
CREATE TABLE `user_activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for user_activity_logs
INSERT INTO `user_activity_logs` VALUES (1,2,'account_created','User account created with role: chairman',NULL,NULL,'2025-05-02 22:57:50');
INSERT INTO `user_activity_logs` VALUES (2,3,'account_created','User account created with role: manager',NULL,NULL,'2025-05-02 22:57:51');
INSERT INTO `user_activity_logs` VALUES (3,4,'account_created','User account created with role: finance',NULL,NULL,'2025-05-02 22:57:51');
INSERT INTO `user_activity_logs` VALUES (4,5,'account_created','User account created with role: teacher',NULL,NULL,'2025-05-02 22:57:51');
INSERT INTO `user_activity_logs` VALUES (5,6,'account_created','User account created with role: superadmin',NULL,NULL,'2025-05-02 22:57:51');
INSERT INTO `user_activity_logs` VALUES (6,7,'account_created','User account created with role: finance',NULL,NULL,'2025-05-02 22:57:51');
INSERT INTO `user_activity_logs` VALUES (7,6,'password_reset','Reset password for user ID: 4','::1',NULL,'2025-05-02 23:33:23');
INSERT INTO `user_activity_logs` VALUES (8,6,'user_suspended','Suspended user ID: 3','::1',NULL,'2025-05-02 23:33:49');

-- Table structure for user_permissions
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_name` varchar(100) NOT NULL,
  `granted_by` int(11) DEFAULT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission` (`user_id`,`permission_name`),
  KEY `granted_by` (`granted_by`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for user_permissions
INSERT INTO `user_permissions` VALUES (1,2,'manage_departments',6,'2025-05-02 23:23:06',NULL,'2025-05-02 23:23:06','2025-05-02 23:23:06');
INSERT INTO `user_permissions` VALUES (2,2,'view_reports',6,'2025-05-02 23:46:00',NULL,'2025-05-02 23:46:00','2025-05-02 23:46:00');

-- Table structure for user_reports
DROP TABLE IF EXISTS `user_reports`;
CREATE TABLE `user_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `generated_by` int(11) DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','completed','failed') DEFAULT 'completed',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `user_reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_reports_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Table structure for user_settings
DROP TABLE IF EXISTS `user_settings`;
CREATE TABLE `user_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `login_notification` tinyint(1) DEFAULT 0,
  `account_lockout_threshold` int(11) DEFAULT 5,
  `session_timeout` int(11) DEFAULT 30,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `user_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('superadmin','chairman','manager','finance','teacher','servant') NOT NULL,
  `status` enum('pending','active','inactive','suspended') DEFAULT 'pending',
  `name` varchar(100) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `date_joined` date DEFAULT NULL,
  `account_number` varchar(20) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `bank_branch` varchar(100) DEFAULT NULL,
  `membership_number` varchar(50) DEFAULT NULL,
  `membership_date` date DEFAULT NULL,
  `credit_eligible` tinyint(1) DEFAULT 0,
  `credit_score` int(11) DEFAULT 0,
  `monthly_contribution` decimal(10,2) DEFAULT 0.00,
  `total_contribution` decimal(10,2) DEFAULT 0.00,
  `available_balance` decimal(10,2) DEFAULT 0.00,
  `profile_image` varchar(255) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `password_reset_token` varchar(100) DEFAULT NULL,
  `password_reset_expires` timestamp NULL DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT 0,
  `email_verification_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `account_number` (`account_number`),
  UNIQUE KEY `membership_number` (`membership_number`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  KEY `idx_department` (`department`),
  KEY `idx_employee_id` (`employee_id`),
  KEY `idx_account_number` (`account_number`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for users
INSERT INTO `users` VALUES (1,'admin','$2y$10$hxbUkVlb88a06eW4oIVase2LxMfCV3fcgrXAEwHzIRC2kSUsAhfOm','admin@dutsca.com','superadmin','active','System Administrator',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SA001',NULL,0,0,0.00,0.00,0.00,NULL,NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:50','2025-05-02 22:57:50',NULL,NULL);
INSERT INTO `users` VALUES (2,'cherinet','$2y$10$rLrWPfUCc6jTeLUygyP9D.EavY52lHYcDdGrCFTc1rDH9HY5PXgvu','cherinet@dutsca.com','chairman','active','Cherinet Aweke',+251911223344,'Administration','EMP001','Department Chairman','2024-01-01','ACC001','Commercial Bank of Ethiopia','Addis Ababa','MEM001','2024-01-01',1,0,1000.00,0.00,0.00,NULL,NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:50','2025-05-02 22:57:50',NULL,NULL);
INSERT INTO `users` VALUES (3,'cherean','$2y$10$rLrWPfUCc6jTeLUygyP9D.EavY52lHYcDdGrCFTc1rDH9HY5PXgvu','cherean@dutsca.com','manager','suspended','Cherean Solomon',+251922334455,'Management','EMP002','General Manager','2024-01-01','ACC002','Dashen Bank','Addis Ababa','MEM002','2024-01-01',1,0,1000.00,0.00,0.00,NULL,NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:50','2025-05-02 23:33:48',NULL,NULL);
INSERT INTO `users` VALUES (4,'efi','$2y$10$Zc8X2Yp40vY8U1lMexlruufafHTnbSmlfwFHS8RMGy0BpnQqQETLC','efi@dutsca.com','finance','active','Efrem Tadesse',+251933445566,'Finance','EMP003','Finance Head','2024-01-01','ACC003','Awash Bank','Addis Ababa','MEM003','2024-01-01',1,0,1000.00,0.00,0.00,NULL,NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:51','2025-05-02 23:33:23',NULL,NULL);
INSERT INTO `users` VALUES (5,'du','$2y$10$rLrWPfUCc6jTeLUygyP9D.EavY52lHYcDdGrCFTc1rDH9HY5PXgvu','du@dutsca.com','teacher','active','Dureti Ahmed',+251944556677,'Teaching','EMP004','Senior Teacher','2024-01-01','ACC004','United Bank','Addis Ababa','MEM004','2024-01-01',1,0,1000.00,0.00,0.00,NULL,NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:51','2025-05-02 22:57:51',NULL,NULL);
INSERT INTO `users` VALUES (6,'cherinetadmin','$2y$10$rLrWPfUCc6jTeLUygyP9D.EavY52lHYcDdGrCFTc1rDH9HY5PXgvu','cherinetadmin@gmail.com','superadmin','active','Cherinet Admin',+251900000001,'','EMP005','System Superadmin','2024-01-01','ACC005','Commercial Bank of Ethiopia','Addis Ababa','MEM005','2024-01-01',1,0,1000.00,0.00,0.00,'profile_6_1746253520.jpg',NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:51','2025-05-02 23:25:20',NULL,NULL);
INSERT INTO `users` VALUES (7,'cherinetfinance','$2y$10$rLrWPfUCc6jTeLUygyP9D.EavY52lHYcDdGrCFTc1rDH9HY5PXgvu','cherinetfinance@gmail.com','finance','active','Cherinet Finance',+251900000002,'Finance','EMP006','Finance Officer','2024-01-01','ACC006','Awash Bank','Addis Ababa','MEM006','2024-01-01',1,0,1000.00,0.00,0.00,NULL,NULL,0,NULL,NULL,1,NULL,'2025-05-02 22:57:51','2025-05-02 22:57:51',NULL,NULL);
